from project.beverage.beverage import Beverage

class ColdBeverage(Beverage):
    pass

#test code
# cold_tea = ColdBeverage("Nestea", 1.5, 250)
# print(cold_tea.__dict__)