import unittest
from project.student import Student


class StudentTests(unittest.TestCase):

    def test_student_init__if_courses_None__expect_initialization(self):
        student = Student("Hans", None)
        self.assertEqual("Hans", student.name)
        self.assertEqual({}, student.courses)

    def test_student_init__if_courses_not_None__expect_initialization(self):
        courses = {"Basics": [], "Fundamentals": []}
        student = Student("Hans", courses)
        self.assertEqual("Hans", student.name)
        self.assertEqual(courses, student.courses)

    def test_student_enroll__if_course_not_found_and_notes_to_add__expect_to_add_course_and_notes(self):
        student = Student("Hans", None)
        expected_msg = "Course and course notes have been added."
        actual_msg = student.enroll("Fundamentals", ["note1, note2"], "")
        self.assertEqual(expected_msg, actual_msg)

    def test_student_enroll__if_course_not_found_and_notes_to_add_is_Y_expect_to_add_course_and_notes(self):
        student = Student("Hans", None)
        expected_msg = "Course and course notes have been added."
        actual_msg = student.enroll("Fundamentals", ["note1, note2"], "Y")
        self.assertEqual(expected_msg, actual_msg)

    def test_student_enroll__if_course_not_found__expect_to_add_course(self):
        student = Student("Hans", None)
        expected_msg = "Course has been added."
        actual_msg = student.enroll("Advanced", ["notes"], "add empty list")
        self.assertEqual(expected_msg, actual_msg)

    def test_student_enroll__if_course_found__expect_to_add_notes(self):
        student = Student("Hans", None)
        student.courses["OOP"] = []
        expected_msg = "Course already added. Notes have been updated."
        actual_msg = student.enroll("OOP", ["note1", "note2"])
        self.assertEqual(expected_msg, actual_msg)

    def test_student_add_notes__if_course_not_found__expect_exception(self):
        student = Student("Hans", None)
        with self.assertRaises(Exception) as ex:
            student.add_notes("Basics", ["note1", "note2"])
        self.assertEqual("Cannot add notes. Course not found.", str(ex.exception))

    def test_student_add_notes__if_course_found__expect_to_add_notes(self):
        student = Student("Hans", None)
        student.courses["OOP"] = []
        expected_msg = "Notes have been updated"
        actual_msg = student.add_notes("OOP", "note1")
        self.assertEqual(expected_msg, actual_msg)

    def test_student_leave_course__if_course_not_found__expect_exception(self):
        student = Student("Hans", None)
        with self.assertRaises(Exception) as ex:
            student.leave_course("Algorithms")
        self.assertEqual("Cannot remove course. Course not found.", str(ex.exception))

    def test_student_leave_course__if_course_found__expect_course_to_be_removed(self):
        student = Student("Hans", None)
        student.courses["OOP"] = []
        expected_msg = "Course has been removed"
        actual_msg = student.leave_course("OOP")
        self.assertEqual(expected_msg, actual_msg)

if __name__ == "__main__":
    unittest.main()