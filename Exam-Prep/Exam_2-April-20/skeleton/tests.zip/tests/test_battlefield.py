import unittest

class BattleFieldTests(unittest.TestCase):
    pass

if __name__ == "__main__":
    unittest.main()